SATUUU99 Brand Deck

14 individual 1920 × 1080 slides and an editable PowerPoint.

Install the included Playfair Display and Plus Jakarta Sans fonts before editing the PowerPoint to preserve typography. Their Open Font Licence files are included.

Text and palette swatches are native editable PowerPoint elements. Logos, patterns and mockups preserve the supplied raster references, whose source resolution limits enlargement. No original vector masters were supplied.

The spa images are existing generated mood imagery, not documentary photographs of the studio.
